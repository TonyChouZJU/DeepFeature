'''
Created on 2011-6-23

@author: Chine
'''
VERSION = (0, 0, 1)

from aqua import aqua
from colorize import colorize
from comic import comic
from darkness import darkness
from diffuse import diffuse
from find_edge import find_edge
from glowing_edge import glowing_edge
from ice import ice
from inosculate import inosculate
from lighting import lighting
from magic import magic
from moire_fringe import moire_fringe
from molten import molten
from mosaic import mosaic
from oil_painting import oil_painting
from paper_cut import paper_cut
from pencil import pencil
from pinch import pinch
from relief import relief
from sepia import sepia
from sketch import sketch
from solarize import solarize
from spherize import spherize
from subtense import subtense
from swirl import swirl
from wave import wave
from whim import whim
from emboss import emboss
